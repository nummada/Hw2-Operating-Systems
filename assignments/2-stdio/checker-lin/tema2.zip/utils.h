
int get_file_descriptor_by_flag(const char *pathname, const char *mode);
