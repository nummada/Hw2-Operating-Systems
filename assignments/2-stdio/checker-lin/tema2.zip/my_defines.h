#ifndef DEFINES
#define DEFINES

#define TRUE 1
#define FALSE 0
#define BUF_MAX_SIZE 4096

enum operations {READ, WRITE, FLUSH};

#endif
